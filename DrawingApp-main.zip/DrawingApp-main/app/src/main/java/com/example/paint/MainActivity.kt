package com.example.paint

import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import androidx.core.content.ContextCompat
import androidx.core.view.get
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.dialog_brush_size.*



class MainActivity : AppCompatActivity() {

    private var myCurrentBrushColor: ImageButton? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Setting Brush Attributes
        drawingView.setSizeBrush(20.toFloat())
        myCurrentBrushColor = colorPallet[1] as ImageButton
        myCurrentBrushColor!!.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                R.drawable.pallet_pressed
            )
        )

        imageButtonBrush.setOnClickListener {
            brushSizeChooserDialog()
        }

        // Undo button
        val imageButtonUndo = findViewById<ImageButton>(R.id.imageButtonUndo)
        imageButtonUndo.setOnClickListener {
            drawingView.onClickUndo()
        }
    }

    private fun brushSizeChooserDialog() {
        val brushDialog = Dialog(this)
        brushDialog.setContentView(R.layout.dialog_brush_size)

        brushDialog.setTitle("Brush Size: ")
        val smallButton = brushDialog.imageButtonSmall
        val mediumButton = brushDialog.imageButtonMedium
        val largeButton = brushDialog.imageButtonLarge

        smallButton.setOnClickListener {
            drawingView.setSizeBrush(10.toFloat())
            brushDialog.dismiss()
        }

        mediumButton.setOnClickListener {
            drawingView.setSizeBrush(20.toFloat())
            brushDialog.dismiss()
        }

        largeButton.setOnClickListener {
            drawingView.setSizeBrush(30.toFloat())
            brushDialog.dismiss()
        }

        brushDialog.show()
    }

    // changes the view of the color pallet when its clicked
    fun paintClicked(view: View) {
        if (view != myCurrentBrushColor) {
            val imageButton = view as ImageButton
            val colorTag = imageButton.tag.toString()

            // Setting newly chosen color pallet to pressed
            drawingView.setColor(colorTag)
            imageButton.setImageDrawable(
                ContextCompat.getDrawable(
                    this,
                    R.drawable.pallet_pressed
                )
            )

            // Set the changed color pallet to normal
            myCurrentBrushColor!!.setImageDrawable(
                ContextCompat.getDrawable(
                    this,
                    R.drawable.pallet_normal
                )
            )
            myCurrentBrushColor = view
        }
    }
}